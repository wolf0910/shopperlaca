
        <!--<link rel="shortcut icon" href="../admin_template//favicon.ico">-->
        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="stylesheet" href="../admin_template/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../admin_template/dist/css/veneto-admin.min.css">
        <link rel="stylesheet" href="../admin_template/demo/css/demo.css">
        <link rel="stylesheet" href="../admin_template/dist/assets/font-awesome/css/font-awesome.css">

        <link rel="stylesheet" href="../admin_template/dist/assets/plugins/jquery-jvectormap/jquery-jvectormap-1.2.2.css"/>
        <link rel="stylesheet" href="../admin_template/dist/css/plugins/rickshaw.min.css">
        <link rel="stylesheet" href="../admin_template/dist/css/plugins/morris.min.css">
        <link rel="stylesheet" href="../admin_template/dist/css/plugins/jquery-select2.min.css">

        <link rel="stylesheet" href="../admin_template/dist/css/plugins/jquery-dataTables.min.css">

         <link rel="stylesheet" href="../admin_template/dist/css/plugins/morris.min.css">

        <!-- my custom -->
        <link rel="stylesheet" href="lib/fontawesome-free-5.8.1-web/css/all.css" crossorigin="anonymous">

        <!-- Numberic stepper -->
        
        <link rel="stylesheet" href="lib/daterangepicker/daterangepicker.css">
        <link rel="stylesheet" href="lib/stepper/jquery.stepper.min.css">
        
        <link rel="stylesheet" href="css/css_crud_form.css">

        <link rel="stylesheet" href="css/my_custom.css">

        <!--[if lt IE 9]>
        <script src="../admin_template/dist/assets/libs/html5shiv/html5shiv.min.js"></script>
        <script src="../admin_template/dist/assets/libs/respond/respond.min.js"></script>
        <![endif]-->
